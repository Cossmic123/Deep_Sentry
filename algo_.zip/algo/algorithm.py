from .dijkstra import dijkstra
from .astar import astar
from .greedy import greedy
from .qlearning import q_learning
from .planner import planner

def algorithm(start_index,goal_index,width,height,costmap,resolution,origin,grid_viz):
    return planner(start_index,goal_index,width,height,costmap,resolution,origin,grid_viz)