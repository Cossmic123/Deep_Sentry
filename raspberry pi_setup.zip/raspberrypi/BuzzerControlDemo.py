import time
import Board

Board.setBuzzer(0) #  OFF

Board.setBuzzer(1) #  ON
time.sleep(0.1) #  Delay
Board.setBuzzer(0) # OFF

time.sleep(1) # Delay

Board.setBuzzer(1)
time.sleep(0.5)
Board.setBuzzer(0)