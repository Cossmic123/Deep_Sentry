#!/usr/bin/python3
#coding=utf8
import sys
sys.path.append('/home/pi/TurboPi/')
import cv2
import time
import math
import signal
import Camera
import threading
import numpy as np
import yaml_handle
import pandas as pd
import HiwonderSDK.Sonar as Sonar
import HiwonderSDK.Board as Board
import HiwonderSDK.mecanum as mecanum

#  Ultrasonic Obstacle
if sys.version_info.major == 2:
    print('Please run this program with python3!')
    sys.exit(0)

car = mecanum.MecanumChassis()

speed = 40
old_speed = 0
distance = 500
Threshold = 30.0
distance_data = []

TextSize = 12
TextColor = (0, 255, 255)

turn = True
forward = True
HWSONAR = None
stopMotor = True
__isRunning = False


# Initial Position
def initMove():
    car.set_velocity(0,90,0)
    servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path)
    servo1 = servo_data['servo1']
    servo2 = servo_data['servo2']
    Board.setPWMServoPulse(1, servo1, 1000)
    Board.setPWMServoPulse(2, servo2, 1000)

#  Reset Variables
def reset():
    global turn
    global speed
    global forward
    global distance
    global old_speed
    global Threshold
    global stopMotor
    global __isRunning
    
    speed = 40
    old_speed = 0
    distance = 500
    Threshold = 30.0
    turn = True
    forward = True
    stopMotor = True
    __isRunning = False
    
#  APP Initialization
def init():
    print("Avoidance Init")
    initMove()
    reset()
    
__isRunning = False
# App starts calling game program
def start():
    global __isRunning
    global stopMotor
    global forward
    global turn
    
    turn = True
    forward = True
    stopMotor = True
    __isRunning = True
    print("Avoidance Start")

#  App stops calling game program 
def stop():
    global __isRunning
    __isRunning = False
    car.set_velocity(0,90,0)
    time.sleep(0.3)
    car.set_velocity(0,90,0)
    print("Avoidance Stop")

#  Exit the game
def exit():
    global __isRunning
    __isRunning = False
    car.set_velocity(0,90,0)
    time.sleep(0.3)
    car.set_velocity(0,90,0)
	# The movement control function. The linear velocity is 0 (0~100), the direction angle is 90(0~360), and the yaw velocity is 0(-2~2).
    HWSONAR.setPixelColor(0, Board.PixelColor(0, 0, 0))
    HWSONAR.setPixelColor(1, Board.PixelColor(0, 0, 0))
    print("Avoidance Exit")
 #Set speed 
def setSpeed(args):
    global speed
    speed = int(args[0])
    return (True, ())
 
#     set threshold
def setThreshold(args):
    global Threshold
    Threshold = args[0]
    return (True, (Threshold,))

# get the current threshold
def getThreshold(args):
    global Threshold
    return (True, (Threshold,))

#  Robot movement processing
def move():
    global turn
    global speed
    global forward
    global distance
    global Threshold
    global old_speed
    global stopMotor
    global __isRunning

    while True:
        if __isRunning:   
            if speed != old_speed:   
                old_speed = speed
                car.set_velocity(speed,90,0) 
                
            if distance <= Threshold:   
                if turn:
                    turn = False
                    forward = True
                    stopMotor = True
                    car.set_velocity(0,90,-0.5) 
                    time.sleep(0.5)
                
            else:
                if forward: 
                    turn = True
                    forward = False
                    stopMotor = True
                    car.set_velocity(speed,90,0) 
                stopMotor = False 
                car.set_velocity(0,90,0)  
            turn = True
            forward = True
            time.sleep(0.03)
 
#   Run child thread
th = threading.Thread(target=move)
th.setDaemon(True)
th.start()

#   Robot image and sensor detection processing
def run(img):
    global HWSONAR
    global distance
    global distance_data
    
    dist = HWSONAR.getDistance() / 10.0 # Get the distance data of ultrasonic sensor

    distance_data.append(dist) #  The distance data cache list
    data = pd.DataFrame(distance_data)
    data_ = data.copy()
    u = data_.mean()  # calculate mean
    std = data_.std()  #   calculate standard deviation

    data_c = data[np.abs(data - u) <= std]
    distance = data_c.mean()[0]

    if len(distance_data) == 5: #   Take the average from multiple testing 
        distance_data.remove(distance_data[0])

    return cv2.putText(img, "Dist:%.1fcm"%distance, (30, 480-30), cv2.FONT_HERSHEY_SIMPLEX, 1.2, TextColor, 2)  #   Print the measured distance on the screen


# Processing before exit 
def manual_stop(signum, frame):
    global __isRunning
    
    print('Closing...')
    __isRunning = False
    car.set_velocity(0,90,0)  #   Turn off all motors

if __name__ == '__main__':
    init()
    start()
    HWSONAR = Sonar.Sonar()
    camera = Camera.Camera()
    camera.camera_open(correction=True) #  Enable distortion correction which is not enabled by default.
    signal.signal(signal.SIGINT, manual_stop)
    while __isRunning:
        img = camera.frame
        if img is not None:
            frame = img.copy() #  Copy image
            Frame = run(frame)  
            frame_resize = cv2.resize(Frame, (320, 240)) #    Resize the frame to 230*240
            cv2.imshow('frame', frame_resize)
            key = cv2.waitKey(1)
            if key == 27:
                break
        else:
            time.sleep(0.01)
    camera.camera_close()
    cv2.destroyAllWindows()
    